export default Object.assign({}, {
  importantNoticeDisplayed: false // If there is important notice need to be displayed, change the value to false
});
