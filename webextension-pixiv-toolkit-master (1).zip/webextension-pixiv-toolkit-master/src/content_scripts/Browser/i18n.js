import { I18n } from '@/modules/Browser';

export default I18n.getI18n();
