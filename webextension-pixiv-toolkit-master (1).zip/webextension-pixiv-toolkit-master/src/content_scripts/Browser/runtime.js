import { Runtime } from '@/modules/Browser';

export default Runtime.getRuntime();
