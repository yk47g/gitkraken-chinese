import { Storage } from '@/modules/Browser';

export default Storage.getStorage();
