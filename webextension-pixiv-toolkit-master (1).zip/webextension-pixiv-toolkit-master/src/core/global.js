if (PRESET_BROWSER === 'firefox') {
    window.$_browser = 'firefox';
} else {
    window.$_browser = 'default';
}