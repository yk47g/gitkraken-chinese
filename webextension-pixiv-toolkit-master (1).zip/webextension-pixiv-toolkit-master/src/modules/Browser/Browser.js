const Browser = {
    getBrowser () {
        return window.chrome || chrome || browser;
    }
}

export default Browser;
