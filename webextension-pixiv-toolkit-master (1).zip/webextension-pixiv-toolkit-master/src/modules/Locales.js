import localeEn from '../statics/_locales/en/messages.json';
import localeZhCN from '../statics/_locales/zh_CN/messages.json';

export default {
  localeEn: localeEn,
  localeZhCN: localeZhCN
};
